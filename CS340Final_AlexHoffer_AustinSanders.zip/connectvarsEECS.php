<?php
  // Define database connection constants
  define('DB_HOST', 'classmysql.engr.oregonstate.edu');
  define('DB_USER', 'cs340_hoffera');
  define('DB_PASSWORD', 'Raymondis201994___');
  define('DB_NAME', 'cs340_hoffera');
?>
